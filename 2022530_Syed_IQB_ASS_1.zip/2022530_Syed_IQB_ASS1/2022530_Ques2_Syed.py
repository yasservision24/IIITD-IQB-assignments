# Smith-Waterman_algorithm for global alignment is dynamic programming based algoritm for finding optimal local alignment.
# Complexity =O(mn), where m and n are length of two sequences
# Works in two step, first is Matrix creation. 
# First fill the 0 in the top left cell of matrix,
# Then fill the 0 in  the first row and first column.
# Then fill matrix based on the below function.
#  function:
#  F(i−1,j−1)+match_score/mismatch_score  
#  F(i−1,j)+gap_penalty
#  F(i,j−1)+gap_penalty
#  0
# Then take max of the above three to fill the matrix at i,j
#Then second step, backtracking is done to get the optimal alignment,Backtrackign starts from the highest score in the matrix.
# Thus, In Smith waterman there is not any negative no.

# Implementaion in Python
#Importing neccessary libraries

# The given code is for global alignment but we can modify it for local alignment by some modifications
"""numpy (imported as np) is a library for numerical computing in Python. It provides support for large, multi-dimensional arrays and matrices, along with a collection of mathematical functions to operate on these arrays."""
"""pandas (imported as pd) is a library for data manipulation and analysis. It offers data structures and operations for manipulating numerical tables"""
import numpy as np 
import pandas as pd

# Declaration OF function nw
"""Declaration of function sw,smith-waterman,with parametres x,y where x,y are the lengths of seq1 and seq2
# match=2 is the the score of match,mismatch=-1 means the mismatch score is -1 or say penalty,similary for gap =-3.
x and y: These are the sequences that need to be aligned. They are the  strings representing nucleotide ."""
def sw(x, y, match=2, mismatch=-1, gap=-3):  # Here given mismatch score and gap penlaty is different from ques 1
    nx = len(x) #Here we are assigning the length of of seqeunce 1 in the variable nx, by using the len method,len gives the lenght of string
    ny = len(y) #Here we are assigning the length of of seqeunce 2 in the variable ny, by using the len method,len gives the lenght of string

    
    # Initialization of the matrix.
    """nx + 1 corresponds to the length of sequence x plus 1, which includes an additional row for representing the case where there is no character from sequence x aligned.
    Similarly, ny + 1 corresponds to the length of sequence y plus 1, with an additional column for the case where there is no character from sequence y aligned."""
    F= np.zeros((nx + 1, ny + 1)) # np.zeros((nx + 1, ny + 1)): This creates a NumPy array filled with zeros. The size of the array is (nx + 1) rows by (ny + 1) columns.

# MODIFICATION 1  For local alignment we put the zero in the first row and first column
    # So, there is no need for this code in local alignment
    """F[:, 0] = np.linspace(0, -gap * nx, nx + 1)
    F[0, :] = np.linspace(0, -gap * ny, ny + 1)"""
    

    
# Modification 2, We have to keep track of the Maximum score and its index for backtracking
    # in local alignment,as in local alignment,we backtrack from the highest score in the matrix
    max_score = 0 #max_score: stores the highest score encountered  during the dynamic programming matrix filling process. It is initialized to 0 before the matrix filling begins.
    max_i = 0 # max_i:  stores the row index of the cell with the highest score encountered . It  keeps track of the position of the highest scoring cell in matrix .
    max_j = 0 #max_j:  stores the column index of the cell with the highest score encountered . it  keeps track of the position of the highest scoring cell.
    
    
    # Correction of BUG 1, i.e. Pointer P must be declared and initialized  before filling of Matrix F
    #Pointers to trace through an optimal alignment.
    """P = np.zeros((nx + 1, ny + 1), dtype=int): This line initializes a matrix P with dimensions (nx + 1) x (ny + 1) filled with zeros.
    """
# Modification 3   Here the matrix P would not have 3 and 4 in first columns and row.As in local alignment they would be zero.
    P = np.zeros((nx + 1, ny + 1), dtype=int)
    """P[:, 0] = 3 # No need of this
    P[0, :] = 4"""
    
    # Matrix filling.
    for i in range(1, nx + 1):
        for j in range(1, ny + 1):
            #Completion Of Incomplete code
            # Calculate the scores for three possible scenarios:
            # 1. Match/mismatch score
            match_score = match if x[i - 1] == y[j - 1] else mismatch
            diagonal_score = F[i - 1, j - 1] + match_score        
            # 2. Gap is introduced in seq y
            gap_3_score = F[i - 1, j] + gap   
            # 3. Gap is itroduced in seq x
            gap_4_score = F[i, j - 1] + gap  
            # Choose the maximum score among the three possibilities
# MODIFICATION 4  here in local alignmnet we take the max of  four quatities i,e,diagonal_score, gap_3_score, gap_4_score and 0
           # So if there is a negative value , it becomes 0 in the local alignment
            """ max_score = max(diagonal_score, gap_3_score, gap_4_score)"""
           
            F[i,j] = max(0,diagonal_score, gap_3_score, gap_4_score)
            
              # Update the score matrix
#MODIFICATION 5   here in local alignment, we need to keep track of max value and its index,But it was not needed in global alignment.

            if F[i, j] >= max_score:  # checking if the score in the current cell (i, j) of  matrix F is greater than or equal to the current maximum score (max_score).
                max_score = F[i, j]  # max_score is updated to the score in cell (i, j). This ensures that max_score always holds the highest score encountered
                max_i = i  # max_i and max_j are updated to store the row index (i) and column index (j) of the cell with the maximum score. 
                max_j = j  #  These indices help in keeping track of the position of the highest scoring cell in the dynamic programming matrix.
                
             # Update the pointer matrix based on which option gives the maximum score

#Modification 6
            if F[i, j] == diagonal_score:
                P[i, j] += 2  # Represents diagonal movement
            if F[i, j] == gap_3_score:
                P[i, j] += 3  # Represents vertical movement
            if F[i, j] == gap_4_score:
                P[i, j] += 4  # Represents horizontal movement





    # BUG 1 -  Pointer should be decalred  and initialized before filling of Matrix F
    #Pointers to trace through an optimal alignment.
    """P = np.zeros((nx + 1, ny + 1), dtype=int)
    P[:, 0] = 3
    P[0, :] = 4"""


    """df = pd.DataFrame(F, index=['-'] + list(x), columns=['-'] + list(y)): This line creates a pandas DataFrame df using the scores stored in the matrix F.
    The index parameter is set to ['-'] + list(x), which means the row labels of the DataFrame will include a dash '-' followed by each character in sequence x.
    This includes an additional dash at the beginning to represent the case where there's a gap in sequence y.
    The columns parameter is set to ['-'] + list(y), which means the column labels of the DataFrame will include a dash '-' followed by each character in sequence y. 
    Similarly, this includes an additional dash at the beginning to represent the case where there's a gap in sequence x"""
    print("Scoring Matrix:")
    df = pd.DataFrame(F, index=['-'] + list(x), columns=['-'] + list(y))
    print(df)
    
    
    
# Till here we have achieved the task of creating the scoring matrix and filling it.
# Uptill here, I maintained the given code structure,found &corrected the BUG and completed the code for Matrix filling and modified it for local alignment..
# And We also have made the P matrix to keep the record of movement for backtracking.
# We also keep track the record of highest score and its cell index for backtracking in the max score and max_i and max_j.
# Now we will do backtracking to get the optimal  local alignment.




    # Trace through an optimal alignment.
#MODIFICATION 7   here instead of i=nx and j=ny, we have to use i=max_i,and j=max_j,,as in local alignment we backtrack from max index instead of bottom right
    """i = nx
    j = ny"""
    
    i=max_i 
    j=max_j
    rx = [] # Intialise lists for optimal alignmenty
    ry = [] # # Intialise lists for optimal alignmenty
# MODIFICATION 8,here we add the condition F[i,j]!0,I t is used to stop the backtracking when 0 is encountered in matrix 
    while i > 0 and j > 0 and F[i, j] != 0: # while i > 0 or j > 0:: This while loop continues the traceback process until both i and j reach 0.
       
        #2+3=5,2+4=6,2+3+4=9
        if P[i, j] in [2, 5, 6, 9]: #This condition checks direction of the pointer at position (i, j)  to traceback.
            # Code Completion       # This blocks handles diagonal,diagonal&vertical,horizontal&diagonal,ALL three movements.
            rx.append(x[i-1]) # The characters x[i-1] and y[j-1] (corresponding to the current positions i and j) are appended to rx and ry respectively, as they are aligned.
            ry.append(y[j-1])
            i -= 1  #i and j are decremented by 1 to move to the previous diagonal cell in the pointer matrix.
            j -= 1
            
        # 2+3=5,3+4=7,2+3+4=9    
        elif P[i, j] in [3, 5, 7, 9]:  # elif P[i, j] in [3, 5, 7, 9]:: This condition checks if the pointer at position (i, j) indicates a vertical movement, suggesting the introduction of a gap in sequence y
            # Code Completion          # This blocks handles vertical , vertical&diagonal, horizontal&vertical,ALL three movements.
            rx.append(x[i-1])   # The character x[i-1] (corresponding to the current position i) is appended to rx, indicating the introduction of a gap in sequence y.     
            ry.append('-')      #  dash '-' is appended to ry, indicating that no character from sequence y is aligned at this position.
            i -= 1              # i is decremented by 1 to move to the previous vertical cell in the pointer matrix.
            
        #2+4=6,3+4=7,2+3+4=9    
        elif P[i, j] in [4, 6, 7, 9]: #elif P[i, j] in [4, 6, 7, 9]:: This condition checks if the pointer at position (i, j) indicates a horizontal movement, suggesting the introduction of a gap in sequence x
            # Code Completion         # This blocks handles horizontal , horizontal&diagonal, horizontal&vertical,ALL three movements.
            rx.append('-')      # A dash '-' is appended to rx, indicating that no character from sequence x is aligned at this position.
            ry.append(y[j-1])   # The character y[j-1] (corresponding to the current position j) is appended to ry, indicating the introduction of a gap in sequence x.
            j -= 1   # j is decremented by 1 to move to the previous horizontal cell in the pointer matrix.
            #complete the code

    # Reverse the strings.
    """To obtain the correct order of characters in the aligned sequences,
    we need to reverse the strings stored in rx and ry. This reversal is accomplished using Python's slicing syntax [::-1], which reverses the order of elements in a sequence
    """
    print()
    print("Optimal Local Alignment")
    print("Score",max_score)
    rx = ''.join(rx)[::-1]  #rx = ''.join(rx)[::-1]: This line first joins the characters in the list rx into a single string using ''.join(rx). Then [::-1] reverses the order of characters in this string. 
    ry = ''.join(ry)[::-1]  #ry = ''.join(ry)[::-1]: Similarly, this line joins the characters in the list ry into a single string and reverses the order of characters to obtain the aligned sequence y
    return '\n'.join([rx, ry]) # return '\n'.join([rx, ry]): This line creates a list containing the aligned sequences rx and ry, and then joins these sequences using '\n', which inserts a newline character between them.


seq1 = "GATGCGCAG"
seq2 = "GGCAGTA" 

print(sw(seq1, seq2))

# Uptill here, I maintained the given code structure,found  BUG resolved them and completed the code and modified the given code for local alignment for Backtracking And print the Optimal alignment with Score.
# Thus I have completed the (a) part,I have completed the partial code and found the bugs AND completed (b) part i.e. printing Scoring matrix.

print("##########################################################################################################")
print()
print()



# Now I modified the given code further by adding the print_alignment_with_matches function to print all the local possible local alignemnt.
# So the below code will print the All possible alignment and most optimal local alignment
import numpy as np
import pandas as pd

def smith_waterman_all(x, y, match=2, mismatch=-3, gap=-3):
    # Get the lengths of input sequences
    nx = len(x)
    ny = len(y)

    # Initialization of the matrix.
    F = np.zeros((nx + 1, ny + 1))  # Initialize the scoring matrix
    max_score = 0  # Variable to store the maximum alignment score found
    max_pos = []  # Store positions where maximum score occurs

    # Matrix filling.
    for i in range(1, nx + 1):  # Loop through the rows
        for j in range(1, ny + 1):  # Loop through the columns
            # Calculate scores for all possible alignments at current position
            match_mismatch = match if x[i - 1] == y[j - 1] else mismatch
            scores = [F[i - 1, j - 1] + match_mismatch,  # Diagonal score
                      F[i - 1, j] + gap,  # Upward score
                      F[i, j - 1] + gap,  # Leftward score
                      0]  # Local alignment starts new alignment here
            F[i, j] = max(scores + [0])  # Assign maximum score to current position
            if F[i, j] >= max_score:  # If current score is greater or equal to max score
                max_score = F[i, j]  # Update max score
                max_pos.append((i, j))  # Store position where max score occurs
    
   
    
    # Traceback to find all alignments.
    alignments = []  # Store all alignments
    max_score_alignments = []  # Store alignments with maximum score
    for i, j in max_pos:  # Iterate through positions with max score
        rx, ry = [], []  # Initialize sequences for current alignment
        alignment_score = 0  # Initialize alignment score
        while i > 0 and j > 0 and F[i, j] > 0:  # Traceback until reaching edge of matrix or score becomes zero
            if F[i, j] == 0:
                break
            if F[i, j] == F[i - 1, j - 1] + (match if x[i - 1] == y[j - 1] else mismatch):  # Diagonal move
                alignment_score += match if x[i - 1] == y[j - 1] else mismatch
                rx.append(x[i - 1])
                ry.append(y[j - 1])
                i -= 1
                j -= 1
            elif F[i, j] == F[i - 1, j] + gap:  # Upward move
                alignment_score += gap
                rx.append(x[i - 1])
                ry.append('-')
                i -= 1
            elif F[i, j] == F[i, j - 1] + gap:  # Leftward move
                alignment_score += gap
                rx.append('-')
                ry.append(y[j - 1])
                j -= 1
        alignment = (''.join(rx[::-1]), ''.join(ry[::-1]), alignment_score)  # Construct alignment tuple
        alignments.append(alignment)  # Add alignment to list of alignments
        if alignment_score == max_score:  # If alignment score equals max score
            max_score_alignments.append(alignment)  # Add alignment to list of max score alignments

    return alignments, max_score_alignments

def print_alignment_with_matches(alignment):
    seq1, seq2, _ = alignment  # Extract sequences and alignment score
    matches = ""  # Initialize string to represent matches/mismatches
    for i in range(len(seq1)):  # Iterate over characters in the sequences
        if seq1[i] == seq2[i]:  # If characters match
            matches += "|"  # Represent match with "|"
        else:
            matches += " "  # Represent mismatch with space
    print(seq1)  # Print first sequence
    print(matches)  # Print matches/mismatches
    print(seq2)  # Print second sequence

# Example sequences
seq1 = "GATGCGCAG"
seq2 = "GGCAGTA"

# Obtain alignments and alignments with maximum score
alignments, max_score_alignments = smith_waterman_all(seq1, seq2)

# Print all local alignments and their scores
print("All POSSIBLE Local Alignments and Their Scores:")
for idx, alignment in enumerate(alignments, start=1):
    print(f"Alignment {idx}:")
    print_alignment_with_matches(alignment)
    print("Alignment Score:", alignment[2])
    print()

# Print maximum alignment score
print("Maximum Alignment Score:", max(alignment[2] for alignment in alignments))

# Print alignment(s) with maximum score
print("Alignment(s) with Maximum Score: i.e MOST OPTIMAL  LOCAL alignment")
for idx, alignment in enumerate(max_score_alignments, start=1):
    print(f"Alignment {idx}:")
    print_alignment_with_matches(alignment)
    print("Alignment Score:", alignment[2])
    print()


"""The Smith-Waterman algorithm is a dynamic programming technique used for local sequence alignment,
particularly in bioinformatics. Unlike the Needleman-Wunsch algorithm for global alignment, 
Smith-Waterman focuses on identifying local similarities between sequences by searching for regions of high similarity. 
It achieves this by systematically scoring and extending alignments between subsequences of the input sequences,
using a dynamic programming matrix to efficiently compute alignment scores. The algorithm then traces back from the highest scoring 
cells in the matrix to identify the optimal local alignments, considering matches, mismatches, and gaps. This approach allows 
Smith-Waterman to accurately detect local similarities even in the presence of significant sequence variations, making it a powerful 
tool for biological sequence analysis."""