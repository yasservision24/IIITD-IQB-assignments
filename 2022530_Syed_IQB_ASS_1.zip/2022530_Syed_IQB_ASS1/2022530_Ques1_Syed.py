# Needleman–Wunsch_algorithm for global alignment is dynamic programming based algoritm for finding optimal global alignment.
# Complexity =O(mn), where m and n are length of two sequences
# Works in two step, first is Matrix creation. 
# First fill the 0 in the top left cell of matrix,
# Then fill the first row and first column by adding gap penalty contiously.
# Then fill matrix based on the below function.
#  function:
#  F(i−1,j−1)+match_score/mismatch_score  
#  F(i−1,j)+gap_penalty
#  F(i,j−1)+gap_penalty
# Then take max of the above three to fill the matrix at i,j
#Then second step, backtracking is done to get the optimal alignment,Traceback starts from the bottom right cell of matrix


# Implementaion in Python
#Importing neccessary libraries
"""numpy (imported as np) is a library for numerical computing in Python. It provides support for large, multi-dimensional arrays and matrices, along with a collection of mathematical functions to operate on these arrays."""
"""pandas (imported as pd) is a library for data manipulation and analysis. It offers data structures and operations for manipulating numerical tables"""
import numpy as np 
import pandas as pd


# Declaration OF function nw
"""Declaration of function nw,,needleman-wunsch,with parametres x,y where x,y are the lengths of seq1 and seq2
# match=2 is the the score of match,mismatch=-3 means the mismatch score is -3 or say penalty,similary for gap =-1.
x and y: These are the sequences that need to be aligned. They are the  strings representing nucleotide .
match: This parameter represents the score assigned when two characters in the sequences match. In sequence alignment, this score is positive to reflect the similarity between the aligned characters.
mismatch: This parameter represents the score assigned when two characters in the sequences do not match. In sequence alignment, this score is negative to penalize the mismatch
gap: This parameter represents the score assigned when introducing a gap (insertion or deletion) in one of the sequences during alignment. It's a negative value to penalize the introduction of gaps."""
def nw(x, y, match=2, mismatch=-3, gap=-1): 
    
    nx = len(x) #Here we are assigning the length of of seqeunce 1 in the variable nx, by using the len method,len gives the lenght of string
    ny = len(y) #Here we are assigning the length of of seqeunce 2 in the variable ny, by using the len method,len gives the lenght of string

    
    # Initialization of the matrix.
    """nx + 1 corresponds to the length of sequence x plus 1, which includes an additional row for representing the case where there is no character from sequence x aligned.
    Similarly, ny + 1 corresponds to the length of sequence y plus 1, with an additional column for the case where there is no character from sequence y aligned."""
    F= np.zeros((nx + 1, ny + 1)) # np.zeros((nx + 1, ny + 1)): This creates a NumPy array filled with zeros. The size of the array is (nx + 1) rows by (ny + 1) columns.
    


   # BUG 1  #F[:, 0] = np.linspace(0, -gap * nx, nx + 1) # BUG 1-We have already assigned the gap score to be -1, So here there would be gap instead of -gap in np.linspace(0, -gap * nx, nx + 1) 
   # BUG 2  #F[0, :] = np.linspace(0, -gap * ny, ny + 1) # BUG 2-We have already assigned the gap score to be -1, So here there would be gap instead of -gap in np.linspace(0, -gap * nx, nx + 1) 
    
    
    # Filling the first column and first row of the scoring matrix by gap score.Like -1 -2 -3 
    """F[:, 0] = np.linspace(0, gap * nx, nx + 1): This line assigns scores to the first column of matrix F. It uses np.linspace() to create an array of evenly spaced numbers over a specified interval. 
    Here, the interval is from 0 to gap * nx (inclusive), and nx + 1 is the number of elements in the array. This means that the values in the array will start from 0 and increase by a step size of gap up to gap * nx. 
    These values represent the scores of aligning characters from sequence x with gaps in sequence y.
    F[0, :] = np.linspace(0, gap * ny, ny + 1): This line assigns scores to the first row of matrix F. Similar to the previous line, it uses np.linspace() to create an array of scores, 
    but this time it assigns scores for aligning characters from sequence y with gaps in sequence x. The range of scores is from 0 to gap * ny, and there are ny + 1 elements in the array."""
    # Correction of BUG 1,2
    F[:, 0] = np.linspace(0, gap * nx, nx + 1) # removed negative sign before of  gap*nx
    F[0, :] = np.linspace(0, gap * ny, ny + 1) # removed negative sign before of  gap*ny

    # Correction of BUG 3, i.e. Pointer P must be declared and initialized  before filling of Matrix F
    #Pointers to trace through an optimal alignment.
    """P = np.zeros((nx + 1, ny + 1), dtype=int): This line initializes a matrix P with dimensions (nx + 1) x (ny + 1) filled with zeros.
    P[:, 0] = 3: This line sets all the elements in the first column of the matrix P to 3. In the context of the Needleman-Wunsch algorithm, this indicates that each cell in the first column can only be reached by moving vertically downwards, 
    representing the introduction of gaps in sequence y.
    P[0, :] = 4: Similarly, this line sets all the elements in the first row of the matrix P to 4, indicating that each cell in the first row can only be reached by moving horizontally to the right, representing the introduction of gaps in sequence x"""
    P = np.zeros((nx + 1, ny + 1), dtype=int)
    P[:, 0] = 3
    P[0, :] = 4
   
    # Matrix filling.
    """Matching or mismatching characters: It calculates the score based on whether the characters at positions i-1 in sequence x and j-1 in sequence y match or not.
    Diagonal_score: is calculated by adding the match_score/mismatch_Score to the score found at the previous diagonal cell in the matrix F. 
    This represents the score of aligning the characters at positions i-1 in sequence x and j-1 in sequence y
    gap_3_score represents the score of introducing a gap in sequence y. It's calculated by adding the gap penalty (gap) to the score found at the cell above in the matrix F. 
    This corresponds to aligning a character from sequence x with a gap in sequence y.
    Similarly we have gap_4_score.
    max_score is determined by selecting the maximum value among the three scores calculated: 
    The score matrix F is updated at position (i, j) with the max_score.
    The pointer matrix P is updated at position (i, j) based on which option gave the maximum score. 
    The pointers represent the direction from which the maximum score was attained (diagonal, vertical, or horizontal movement).
    """
    """ 2: Indicates a diagonal movement, aligning characters from both sequences.
        3: Indicates a vertical movement, introducing a gap in sequence y.
        4: Indicates a horizontal movement, introducing a gap in sequence x.
        They are used as flags to indicate different paths in the scoring matrix.
        These are arbitrary in the sense that they are chosen to represent different directions or movements in the algorithm,
        but they could have been chosen differently"""
    for i in range(1, nx + 1):
        for j in range(1, ny + 1):
            #Completion Of Incomplete code
            # Calculate the scores for three possible scenarios:
            # 1. Match/mismatch score
            match_score = match if x[i - 1] == y[j - 1] else mismatch
            diagonal_score = F[i - 1, j - 1] + match_score
            
            # 2. Gap is introduced in seq y
            gap_3_score = F[i - 1, j] + gap
            
            # 3. Gap is itroduced in seq x
            gap_4_score = F[i, j - 1] + gap
            
            # Choose the maximum score among the three possibilities
            max_score = max(diagonal_score, gap_3_score, gap_4_score)
            F[i, j] = max_score  # Update the score matrix
            
            # Update the pointer matrix based on which option gives the maximum score
            if max_score == diagonal_score:
                P[i, j] += 2  # Represents diagonal movement
            if max_score == gap_3_score:
                P[i, j] += 3  # Represents vertical movement
            if max_score == gap_4_score:
                P[i, j] += 4  # Represents horizontal movement


    # BUG 3 -  Pointer should be decalred  and initialized before filling of Matrix F
    #Pointers to trace through an optimal alignment.
    """P = np.zeros((nx + 1, ny + 1), dtype=int)
    P[:, 0] = 3
    P[0, :] = 4"""


    # Print scoring matrix using pandas DataFrame
    """df = pd.DataFrame(F, index=['-'] + list(x), columns=['-'] + list(y)): This line creates a pandas DataFrame df using the scores stored in the matrix F.
    The index parameter is set to ['-'] + list(x), which means the row labels of the DataFrame will include a dash '-' followed by each character in sequence x.
    This includes an additional dash at the beginning to represent the case where there's a gap in sequence y.
    The columns parameter is set to ['-'] + list(y), which means the column labels of the DataFrame will include a dash '-' followed by each character in sequence y. 
    Similarly, this includes an additional dash at the beginning to represent the case where there's a gap in sequence x"""
    print("Scoring Matrix:")
    df = pd.DataFrame(F, index=['-'] + list(x), columns=['-'] + list(y))
    print(df)

# Till here I have achieved the task of creating the scoring matrix and filling it.
# Uptill here, I maintained the given code structure,found &corrected the three BUG and completed the code for Matrix filling.
# And I also have made the P matrix to keep the record of movement for backtracking.
# Now I will do backtracking to get the optimal alignment.

    # Trace through an optimal alignment.
    """As nx and ny represent the length of seqeunce so:
    i = nx and j = ny: These lines initialize i and j to the lengths of sequences x and y respectively.
    Since Python uses 0-based indexing, nx and ny correspond to the positions of the last characters in sequences x and y.
    rx = [] and ry = []: These lines initialize empty lists rx and ry, which will be used to store the characters of the optimal alignment for sequences x and y respectively.
    After this initialization, the loop for tracing back the optimal alignment begins. Starting from the last characters of the sequences, the loop iteratively moves backward following the pointers in the pointer matrix P. 
    The loop continues until it reaches the beginning of either sequence x or y, which corresponds to i = 0 or j = 0"""
    i = nx # Initialise i and j to length of sequences.
    j = ny
    rx = [] # Intialise lists for optimal alignmenty
    ry = [] # Intialise lists for optimal alignmenty
    
    
    """while i > 0 or j > 0: This while loop continues iterating as long as either i or j is greater than 0. It ensures that the traceback process continues until reaching the beginning of both sequences x and y.
    There are 2,3,4,5,6,7,9 i.e. 7 numbers,7 numbers indicate 7 possible movements.
    
    2: Represents a diagonal movement. This indicates aligning characters from both sequences x and y.
    3: Represents a vertical movement. This indicates the introduction of a gap in sequence x, aligning a character from sequence y with a gap in sequence x.
    4: Represents a horizontal movement. This indicates the introduction of a gap in sequence y, aligning a character from sequence x with a gap in sequence y.
    5: Represents a combination of diagonal and vertical movements. Means both diagonal and vertical movements are possible.This occurs when both aligning characters from both sequences and introducing a gap in sequence x contribute to the maximum score.
    6: Represents a combination of diagonal and horizontal movements.Means both diagonal and horizontal movements are possible. This occurs when both aligning characters from both sequences and introducing a gap in sequence y contribute to the maximum score.
    7: Represents a combination of vertical and horizontal movements.Means both horizontal and vertical movements are possible This occurs when both introducing a gap in sequence x and introducing a gap in sequence y contribute to the maximum score.
    9: Represents a combination of diagonal, vertical, and horizontal movements. Means all thee movements are possible.This occurs when all three movements contribute to the maximum score.
"""
    while i > 0 or j > 0: # while i > 0 or j > 0:: This while loop continues the traceback process until both i and j reach 0.
        
        #2+3=5,2+4=6,2+3+4=9
        if P[i, j] in [2, 5, 6, 9]: #This condition checks direction of the pointer at position (i, j)  to traceback.
            # Code Completion       # This blocks handles diagonal,diagonal&vertical,horizontal&diagonal,ALL three movements.
            rx.append(x[i-1]) # The characters x[i-1] and y[j-1] (corresponding to the current positions i and j) are appended to rx and ry respectively, as they are aligned.
            ry.append(y[j-1])
            i -= 1  #i and j are decremented by 1 to move to the previous diagonal cell in the pointer matrix.
            j -= 1
            
        # 2+3=5,3+4=7,2+3+4=9    
        elif P[i, j] in [3, 5, 7, 9]:  # elif P[i, j] in [3, 5, 7, 9]:: This condition checks if the pointer at position (i, j) indicates a vertical movement, suggesting the introduction of a gap in sequence y
            # Code Completion          # This blocks handles vertical , vertical&diagonal, horizontal&vertical,ALL three movements.
            rx.append(x[i-1])   # The character x[i-1] (corresponding to the current position i) is appended to rx, indicating the introduction of a gap in sequence y.     
            ry.append('-')      #  dash '-' is appended to ry, indicating that no character from sequence y is aligned at this position.
            i -= 1              # i is decremented by 1 to move to the previous vertical cell in the pointer matrix.
            
        #2+4=6,3+4=7,2+3+4=9    
        elif P[i, j] in [4, 6, 7, 9]: #elif P[i, j] in [4, 6, 7, 9]:: This condition checks if the pointer at position (i, j) indicates a horizontal movement, suggesting the introduction of a gap in sequence x
            # Code Completion         # This blocks handles horizontal , horizontal&diagonal, horizontal&vertical,ALL three movements.
            rx.append('-')      # A dash '-' is appended to rx, indicating that no character from sequence x is aligned at this position.
            ry.append(y[j-1])   # The character y[j-1] (corresponding to the current position j) is appended to ry, indicating the introduction of a gap in sequence x.
            j -= 1   # j is decremented by 1 to move to the previous horizontal cell in the pointer matrix.

    # Reverse the strings.
    """To obtain the correct order of characters in the aligned sequences,
    we need to reverse the strings stored in rx and ry. This reversal is accomplished using Python's slicing syntax [::-1], which reverses the order of elements in a sequence
    """
    print()
    print("Optimal Alignment")
    print("Score:",F[nx,ny] ) # Left most value of Matrix represent Score
    rx = ''.join(rx)[::-1]  #rx = ''.join(rx)[::-1]: This line first joins the characters in the list rx into a single string using ''.join(rx). Then [::-1] reverses the order of characters in this string. 
    ry = ''.join(ry)[::-1]  #ry = ''.join(ry)[::-1]: Similarly, this line joins the characters in the list ry into a single string and reverses the order of characters to obtain the aligned sequence y
    return '\n'.join([rx, ry]) # return '\n'.join([rx, ry]): This line creates a list containing the aligned sequences rx and ry, and then joins these sequences using '\n', which inserts a newline character between them.
seq1 = "GATGCGCAG"
seq2 = "GGCAGTA" 

print(nw(seq1, seq2))

# Uptill here, I maintained the given code structure,found BUG,resolved them and completed the code for Backtracking And print the Optimal alignment with Score.
# Thus I have completed the (a) part,
# I have completed the partial code and found the bugs AND completed (b) part i.e. printing Scoring matrix.

print("##########################################################################################################")
print()






# MODIFIED CODE for part (c) and (d)
# Now I will modify the code for printing all the optimal alignments with their scores. AND best alignment(s) obtained with its corresponding score.    
# As there are multiple alignment possible for the same score, with same no of gaps, with differnt positions of gaps.
# So, I will use the Affine gap penalty:
                    # Affine gap penalty score: g(g) = -d - (g -1) e
                    # d = gap opening penalty
                    # e = gap extension penalty
                    # g = gap length
                    # d = gap opening penalty →      -1
                    # e = gap extension penalty → - 0.1
                    # g = gap length
                    
                    

#I have added a new function named nw_ALL_optimal_alignment to the above code and rewrite the above code belowe by adding nw_ALL_optimal_alignment function.
# The following code prints the all optimal alignment and their affine gap penalty score.And finally print the best best alignment.
import numpy as np  # Import NumPy for array operations
import pandas as pd

SCR = []  # List to store alignment scores
a = []    # List to store first aligned sequence
b = []    # List to store alignment representation
c = []    # List to store second aligned sequence

def nw_ALL_optimal_alignment(x, y, match=2, mismatch=-3, gap=-1):
    nx = len(x)  # Length of sequence x
    ny = len(y)  # Length of sequence y
    
    # Initialize score and pointer matrices
    F = np.zeros((nx + 1, ny + 1))
    P = np.zeros((nx + 1, ny + 1))
    
    # Initialize first column and row of score matrix
    F[:, 0] = np.linspace(0, nx * gap, nx + 1)
    F[0, :] = np.linspace(0, ny * gap, ny + 1)
    
    # Initialize pointers for first column and row
    P[:, 0] = 3
    P[0, :] = 4
    
    # Fill the score and pointer matrices
    for i in range(1, nx + 1):
        for j in range(1, ny + 1):
            # Calculate scores for three possible scenarios
            
            # 1. Match/mismatch score
            match_score = match if x[i - 1] == y[j - 1] else mismatch
            diagonal_score = F[i - 1, j - 1] + match_score
            
            # 2. Gap is introduced in seq y
            gap_3_score = F[i - 1, j] + gap
            
            # 3. Gap is introduced in seq x
            gap_4_score = F[i, j - 1] + gap
            
            # Choose the maximum score among the three possibilities
            max_score = max(diagonal_score, gap_3_score, gap_4_score)
            F[i, j] = max_score  # Update the score matrix
            
            # Update the pointer matrix based on which option gives the maximum score
            if max_score == diagonal_score:
                P[i, j] += 2  # Represents diagonal movement
            if max_score == gap_3_score:
                P[i, j] += 3  # Represents vertical movement
            if max_score == gap_4_score:
                P[i, j] += 4  # Represents horizontal movement
    
    alignment_score = F[nx, ny]  # Final alignment score
    
    print("\nAll Possible  Optimal Alignments:")
    
    #Modified part starts here for part (C) and (d).
    # Recursive function to generate all possible optimal alignment alignments
    def generate_alignments(i, j, rx='', ry=''):
        counter1 = 0  # Counter to track consecutive gaps count
        counter2=0  # Two counters are used as there are two sequences

        if i == 0 and j == 0:
            # Reverse the strings.
            rx = rx[::-1]
            ry = ry[::-1]
            score = 0
            gap_count1 = 0  # Keep counts of gaps of seq1
            gap_count2=0     # Keep counts of gaps of seq2
            alignment_string = ""  # String to visualize matches and gaps

            # Apply gap extension penalty for any remaining consecutive gaps at the end
            
            
            print(f"Alignment ")
            print("Allignment score:", alignment_score)

            # Print the alignment string with correct positions for matches
            print(rx)
            flag1 = False # Flags are used for maintaing the no of consecutive gaps
            flag2 =  False # Flag1 and Flag2 are for seq1 and seq2
            for k in range(len(rx)):
                if rx[k] == '-' or ry[k] == '-':
                    if  rx[k] == '-':
                        flag1 = True
                        gap_count1 += 1
                        alignment_string += " "  # Mark gap
                        score = score + gap
                        gap_count2=0
                        flag2=False
                    else :
                        flag2 = True
                        gap_count2 += 1
                        alignment_string += " "  # Mark gap
                        score = score + gap
                        gap_count1=0
                        flag1=False
                    
                
                
                    
                if rx[k] == ry[k] and (rx[k] != '-' and ry[k] != '-'):
                    alignment_string += "|"  # Mark match
                    score += match
                    flag1 = False
                    flag2=False
                    gap_count1 = 0
                    gap_count2=0
               
                if rx[k] != ry[k] and (rx[k] != '-' and ry[k] != '-'):
                    alignment_string += " "  # Mark mismatch
                    score += mismatch
                    flag1 = False
                    flag2=False
                    gap_count1=0
                    gap_count2=0
                if(flag1 == True and gap_count1 > 1):
                    counter1 += 1
                    flag1=False
                if(flag2 == True and gap_count2 > 1):
                    counter2 += 1
                    flag2=False
                
            score = score - (counter1+counter2) * 0.1
            
            print(alignment_string)
            print(ry)
            
            print("Score afte using Affine gap penalty: ", score)
            
            # Store alignment details in respective lists
            SCR.append(score)
            a.append(rx)
            b.append(alignment_string)
            c.append(ry)

            
            print()
            print()
            return

        # Traceback to generate all optimal alignments
        if P[i, j] in [2, 5, 6, 9]:
            generate_alignments(i - 1, j - 1, rx + x[i - 1], ry + y[j - 1])

        if P[i, j] in [3, 5, 7, 9]:
            generate_alignments(i - 1, j, rx + x[i - 1], ry + '-')

        if P[i, j] in [4, 6, 7, 9]:
            generate_alignments(i, j - 1, rx + '-', ry + y[j - 1])

    # Start traceback from the bottom-right cell
    generate_alignments(nx, ny)

# Test the function with sequences
seq1 = "GATGCGCAG"
seq2 = "GGCAGTA" 
nw_ALL_optimal_alignment(seq1, seq2)

print()
print()
print()
print()
print("BEST POSSIBLE ALIGNMENT after using Affine gap penalty")

# Find the alignments with maximum score
max_value = max(SCR)
max_indices = [i for i, value in enumerate(SCR) if value == max_value]

# Print the best alignments
for i in max_indices:
    print("Affile gap penalty:", SCR[i])
    print(a[i])
    print(b[i])
    print(c[i])
    print()


# In the modified code, I have added th generate_alignments function to print the all optimal alignments and the best alignment.
# In the modified code, the newly added function do the below task
"""Function Parameters: It takes in i and j as the current positions in the scoring matrix F, and rx and ry as the current alignment strings for sequences x and y.

Base Case: When the function reaches the top-left corner of the scoring matrix, it calculates the alignment score, adjusts it for affine gap penalties if needed, and prints the alignment details.

Traceback: The function recursively traces back through the optimal alignment by examining the pointers in the matrix P. It updates the alignment strings rx and ry based on the movement indicated by the pointers.

Affine Gap Penalties: It keeps track of consecutive gap counts for each sequence and applies affine gap penalties to the alignment score when necessary. It is takes as -0.1

Storing Alignments: Alignment details, including the alignment score, aligned sequences, and alignment string, are stored in respective lists (SCR, a, b, and c).

Recursion: The function calls itself recursively with updated positions and alignment strings until it reaches the base case.

Start Traceback: The traceback process starts from the bottom-right cell of the scoring matrix, representing the end of the alignment.
This modified code  is the Needleman Wunsch Algorithm for global alignment  which is dyanamic programming based and have complexity of O(mn)"""



"""Needleman-Wunsch algorithm, a dynamic programming approach for global sequence alignment.
This algorithm efficiently solves the problem by breaking it down into smaller subproblems and avoiding redundant computations. 
At its core, dynamic programming optimizes the computation of the score matrix F, which represents the scores of optimal alignments for substrings of the input sequences. 
By iteratively filling this matrix and considering previously computed scores, the algorithm ensures that each subproblem is solved only once, 
significantly reducing the overall time complexity. Additionally, dynamic programming is leveraged in the traceback step, where the pointer matrix P is used to reconstruct all possible optimal alignments.
This approach enables the algorithm to efficiently explore different paths from the bottom-right to the top-left cell, generating the optimal alignments without revisiting previously explored solutions. 
Thus, dynamic programming is fundamental to the Needleman-Wunsch algorithm, enabling the efficient computation of optimal alignments for sequences of varying lengths."""