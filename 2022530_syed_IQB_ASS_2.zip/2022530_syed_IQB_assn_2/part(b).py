# Here I am defining  propensities of Amino Acids  Alpha and beta 
# First index represnt alpha helix and second  represnt beta strand
# For this I have made the dictionary to store the values  with key as the one letter code for amino acid

# X represnt no prediction
# S means Strand
# H means helix
parameters = {
    'E': (1.53, 0.26),  # Glutamic acid
    'A': (1.45, 0.97),  # Alanine
    'L': (1.34, 1.22),  # Leucine
    'H': (1.24, 0.71),  # Histidine
    'M': (1.20, 1.67),  # Methionine
    'Q': (1.17, 1.23),  # Glutamine
    'W': (1.14, 1.19),  # Tryptophan
    'V': (1.14, 1.65),  # Valine
    'F': (1.12, 1.28),  # Phenylalanine
    'K': (1.07, 0.74),  # Lysine
    'I': (1.00, 1.60),  # Isoleucine
    'D': (0.98, 0.80),  # Aspartic acid
    'T': (0.82, 1.20),  # Threonine
    'S': (0.79, 0.72),  # Serine
    'R': (0.79, 0.90),  # Arginine
    'C': (0.77, 1.30),  # Cysteine
    'N': (0.73, 0.65),  # Asparagine
    'Y': (0.61, 1.29),  # Tyrosine
    'P': (0.59, 0.62),  # Proline
    'G': (0.53, 0.81)   # Glycine
}


  # here use the window size of 5 as it is for strand
def  calculate_propensity_STRAND(sequence):
    scores = []
    for i in range(len(sequence)-4):
        # Calculate the propensity scores for a hexapeptide
        pentapeptide = sequence[i:i+5]
        P_alpha_count = sum(parameters[residue][1] >= 1 for residue in pentapeptide)

        # Append the propensity score for this window
        scores.append(P_alpha_count)

    return scores
  # here I found the nucleation sites for the alpha helix
  # 


def find_strand_nucleation_sites(sequence):
    nucleation_sites = []
    scores =  calculate_propensity_STRAND(sequence)
    
    for i, score in enumerate(scores):
        if score >= 3:
            nucleation_sites.append((i, i+4, sequence[i:i+5]))
            
    print("Nucleation sites for beta Strands")
    for i in range(len(nucleation_sites)):
        print(nucleation_sites[i])
    print()
    print("...................................................")
    return nucleation_sites


# Here I am extending the seqeunce to both sides if the score of last 4 and first 4>=4 for both alpha helix and beta strand


def extend_strand_regions(sequence, nucleation_sites):
    extended_sites = []
    
    for site in nucleation_sites:
        start_index, end_index, site_sequence = site
        extended_start_index = start_index
        extended_end_index = end_index
        
        # Extend to the left until the propensity sum is less than 4 or we reach the beginning of the sequence
        while extended_start_index > 0:
            # Get the amino acid left to the start index of the nucleation site
            amino_acid = sequence[extended_start_index - 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][1] for residue in site_sequence[0:3]) + parameters[amino_acid][1]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and decrement the start index
            site_sequence = amino_acid + site_sequence
            extended_start_index -= 1
        
        # Extend to the right until the propensity sum is less than 4 or we reach the end of the sequence
        while extended_end_index < len(sequence) - 1:
            # Get the amino acid right to the end index of the nucleation site
            amino_acid = sequence[extended_end_index + 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][1] for residue in site_sequence[-3:]) + parameters[amino_acid][1]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and increment the end index
            site_sequence += amino_acid
            extended_end_index += 1
        
        # Append the extended nucleation site
        extended_sites.append((extended_start_index, extended_end_index, site_sequence))
    
    return extended_sites


        
def print_sequence_with_strand(input_sequence):
    strand_nucleation_sites = find_strand_nucleation_sites(input_sequence)
    strand_regions = extend_strand_regions(input_sequence, strand_nucleation_sites)
    strand_positions = [False] * len(input_sequence)

    for start, end, _ in strand_regions:
        for i in range(start, end+1):
            strand_positions[i] = True
    print(".....................................................................................")
    print("")
    print("")
    print("STRAND REGIONS")
    for i in range(0, len(input_sequence), 50):
        seq_line = input_sequence[i:i+50]
        helix_line = ''.join('S' if strand_positions[j] else 'X' for j in range(i, min(i+50, len(input_sequence))))
        
        print(helix_line.ljust(50))

# Provided input sequence
input_sequence = "MNASSEGESFAGSVQIPGGTTVLVELTPDIHICGICKQQFNNLDAFVAHKQSGCQLTGTSAAAPSTVQFVSEETVPATQTQTTTRTITSETQTITVSAPEFVFEHGYQTYLPTESNENQTATVISLPAKSRTKKPTTPPAQKRLNCCYPGCQFKTAYGMKDMERHLKIHTGDKPHKCEVCGKCFSRKDKLKHMRCHTGVKPYKCKTCDYAAADSSSLNKHLRIHSDERPFKCQICPYASRNSSQLTVHLRSHTASELDDDVPKANCLSTESTDTPKAPVITLPSEAREQMATLGERTFNCCYPGCHFKTVHGMKDLDRHLRIHTGDKPHKCEFCDKCFSRKDNLTMHMRCHTSVKPHKCHLCDYAAVDSSSLKKHLRIHSDERPYKCQLCPYASRNSSQLTVHLRSHTGDTPFQCWLCSAKFKISSDLKRHMIVHSGEKPFKCEFCDVRCTMKANLKSHIRIKHTFKCLHCAFQGRDRADLLEHSRLHQADHPEKCPECSYSCSSAAALRVHSRVHCKDRPFKCDFCSFDTKRPSSLAKHVDKVHRDEAKTENRAPLGKEGLREGSSQHVAKIVTQRAFRCETCGASFVRDDSLRCHKKQHSDQSENKNSDLVTFPPESGASGQLSTLVSVGQLEAPLEPSQDL"


print_sequence_with_strand(input_sequence)


