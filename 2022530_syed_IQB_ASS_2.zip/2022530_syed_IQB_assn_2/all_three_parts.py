# Here I am defining  propensities of Amino Acids  Alpha and beta 
# First index represnt alpha helix and second  represnt beta strand
# For this I have made the dictionary to store the values  with key as the one letter code for amino acid

# X represnt no prediction
# S means Strand
# H means helix
# Here using the one letter code for amino acids and its representation.
parameters = {
    'E': (1.53, 0.26),  # Glutamic acid
    'A': (1.45, 0.97),  # Alanine
    'L': (1.34, 1.22),  # Leucine
    'H': (1.24, 0.71),  # Histidine
    'M': (1.20, 1.67),  # Methionine
    'Q': (1.17, 1.23),  # Glutamine
    'W': (1.14, 1.19),  # Tryptophan
    'V': (1.14, 1.65),  # Valine
    'F': (1.12, 1.28),  # Phenylalanine
    'K': (1.07, 0.74),  # Lysine
    'I': (1.00, 1.60),  # Isoleucine
    'D': (0.98, 0.80),  # Aspartic acid
    'T': (0.82, 1.20),  # Threonine
    'S': (0.79, 0.72),  # Serine
    'R': (0.79, 0.90),  # Arginine
    'C': (0.77, 1.30),  # Cysteine
    'N': (0.73, 0.65),  # Asparagine
    'Y': (0.61, 1.29),  # Tyrosine
    'P': (0.59, 0.62),  # Proline
    'G': (0.53, 0.81)   # Glycine
}

def  calculate_propensity_HELIX(sequence): # here i am using the sliding window approach to find the window of size six as helix where there
    # are more than 4 amino acids having propensity>=4
    scores = []
    for i in range(len(sequence)-5):
        # Calculate the propensity scores for a hexapeptide
        hexapeptide = sequence[i:i+6]
        P_alpha_count = sum(parameters[residue][0] >= 1 for residue in hexapeptide)

        # Append the propensity score for this window
        scores.append(P_alpha_count)

    return scores
  # here use the window size of 5 as it is for strand
def  calculate_propensity_STRAND(sequence):
    scores = []
    for i in range(len(sequence)-4):
        # Calculate the propensity scores for a hexapeptide
        pentapeptide = sequence[i:i+5]
        P_alpha_count = sum(parameters[residue][1] >= 1 for residue in pentapeptide)

        # Append the propensity score for this window
        scores.append(P_alpha_count)

    return scores
  # here I found the nucleation sites for the alpha helix
  # 
def find_helix_nucleation_sites(sequence):
    nucleation_sites = []
    scores =  calculate_propensity_HELIX(sequence)
    
    for i, score in enumerate(scores):
        if score >= 4:
            nucleation_sites.append((i, i+5, sequence[i:i+6]))
    
    
    print()
    print(".......................................................")
    return nucleation_sites

def find_strand_nucleation_sites(sequence):
    nucleation_sites = []
    scores =  calculate_propensity_STRAND(sequence)
    
    for i, score in enumerate(scores):
        if score >= 3:
            nucleation_sites.append((i, i+4, sequence[i:i+5]))
            
    
    print()
    print("...................................................")
    return nucleation_sites


# Here I am extending the seqeunce to both sides if the score of last 4 and first 4>=4 for both alpha helix and beta strand
def extend_helix_regions(sequence, nucleation_sites):
    extended_sites = []
    
    for site in nucleation_sites:
        start_index, end_index, site_sequence = site
        extended_start_index = start_index
        extended_end_index = end_index
        
        # Extend to the left until the propensity sum is less than 4 or we reach the beginning of the sequence
        while extended_start_index > 0:
            # Get the amino acid left to the start index of the nucleation site
            amino_acid = sequence[extended_start_index - 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][0] for residue in site_sequence[0:3]) + parameters[amino_acid][0]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and decrement the start index
            site_sequence = amino_acid + site_sequence
            extended_start_index -= 1
        
        # Extend to the right until the propensity sum is less than 4 or we reach the end of the sequence
        while extended_end_index < len(sequence) - 1:
            # Get the amino acid right to the end index of the nucleation site
            amino_acid = sequence[extended_end_index + 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][0] for residue in site_sequence[-3:]) + parameters[amino_acid][0]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and increment the end index
            site_sequence += amino_acid
            extended_end_index += 1
        
        # Append the extended nucleation site
        extended_sites.append((extended_start_index, extended_end_index, site_sequence))
   
    return extended_sites

def extend_strand_regions(sequence, nucleation_sites):
    extended_sites = []
    
    for site in nucleation_sites:
        start_index, end_index, site_sequence = site
        extended_start_index = start_index
        extended_end_index = end_index
        
        # Extend to the left until the propensity sum is less than 4 or we reach the beginning of the sequence
        while extended_start_index > 0:
            # Get the amino acid left to the start index of the nucleation site
            amino_acid = sequence[extended_start_index - 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][1] for residue in site_sequence[0:3]) + parameters[amino_acid][1]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and decrement the start index
            site_sequence = amino_acid + site_sequence
            extended_start_index -= 1
        
        # Extend to the right until the propensity sum is less than 4 or we reach the end of the sequence
        while extended_end_index < len(sequence) - 1:
            # Get the amino acid right to the end index of the nucleation site
            amino_acid = sequence[extended_end_index + 1]
            # Add the propensity of the extended amino acid and the last three amino acids of the site sequence
            propensity_sum = sum(parameters[residue][1] for residue in site_sequence[-3:]) + parameters[amino_acid][1]
            # If the sum is less than 4, break the loop
            if propensity_sum < 4:
                break
            # Otherwise, include the amino acid in the nucleation site and increment the end index
            site_sequence += amino_acid
            extended_end_index += 1
        
        # Append the extended nucleation site
        extended_sites.append((extended_start_index, extended_end_index, site_sequence))
    
    return extended_sites

def print_sequence_with_helix(input_sequence):
    helix_nucleation_sites = find_helix_nucleation_sites(input_sequence)
    helix_regions = extend_helix_regions(input_sequence, helix_nucleation_sites)
    helix_positions = [False] * len(input_sequence)

    for start, end, _ in helix_regions:
        for i in range(start, end+1):
            helix_positions[i] = True
    print("")
    print("")
    print("HELIX REGIONS")
    for i in range(0, len(input_sequence), 50):
        seq_line = input_sequence[i:i+50]
        helix_line = ''.join('H' if helix_positions[j] else 'X' for j in range(i, min(i+50, len(input_sequence))))
        print(seq_line.ljust(50))
        print(helix_line.ljust(50))
        
def print_sequence_with_strand(input_sequence):
    strand_nucleation_sites = find_strand_nucleation_sites(input_sequence)
    strand_regions = extend_strand_regions(input_sequence, strand_nucleation_sites)
    strand_positions = [False] * len(input_sequence)

    for start, end, _ in strand_regions:
        for i in range(start, end+1):
            strand_positions[i] = True
    print(".....................................................................................")
    print("")
    print("")
    print("STRAND REGIONS")
    for i in range(0, len(input_sequence), 50):
        seq_line = input_sequence[i:i+50]
        helix_line = ''.join('S' if strand_positions[j] else 'X' for j in range(i, min(i+50, len(input_sequence))))
        print(seq_line.ljust(50))
        print(helix_line.ljust(50))

# Provided input sequence
input_sequence = "MNASSEGESFAGSVQIPGGTTVLVELTPDIHICGICKQQFNNLDAFVAHKQSGCQLTGTSAAAPSTVQFVSEETVPATQTQTTTRTITSETQTITVSAPEFVFEHGYQTYLPTESNENQTATVISLPAKSRTKKPTTPPAQKRLNCCYPGCQFKTAYGMKDMERHLKIHTGDKPHKCEVCGKCFSRKDKLKHMRCHTGVKPYKCKTCDYAAADSSSLNKHLRIHSDERPFKCQICPYASRNSSQLTVHLRSHTASELDDDVPKANCLSTESTDTPKAPVITLPSEAREQMATLGERTFNCCYPGCHFKTVHGMKDLDRHLRIHTGDKPHKCEFCDKCFSRKDNLTMHMRCHTSVKPHKCHLCDYAAVDSSSLKKHLRIHSDERPYKCQLCPYASRNSSQLTVHLRSHTGDTPFQCWLCSAKFKISSDLKRHMIVHSGEKPFKCEFCDVRCTMKANLKSHIRIKHTFKCLHCAFQGRDRADLLEHSRLHQADHPEKCPECSYSCSSAAALRVHSRVHCKDRPFKCDFCSFDTKRPSSLAKHVDKVHRDEAKTENRAPLGKEGLREGSSQHVAKIVTQRAFRCETCGASFVRDDSLRCHKKQHSDQSENKNSDLVTFPPESGASGQLSTLVSVGQLEAPLEPSQDL"
print("Length of sequence: ",len(input_sequence))
print_sequence_with_helix(input_sequence)
print_sequence_with_strand(input_sequence)




# Here I am printing the regions where Both Alpha Helix and Beta strands are present and will resolve the conflict based on 
# the condition if the A region containing overlapping helical and strand assignments is considered as a helix
#(or strand) if average propensity of alpha-helix (beta-strand) is greater than that of bets-
#strand (alpha-helix).


# So to break a tie if there are both possible at a certain stretch ,take average propensities of the stretch,and find which is greater
def print_sequence_with_regions(input_sequence):
    helix_nucleation_sites = find_helix_nucleation_sites(input_sequence)
    helix_regions = extend_helix_regions(input_sequence, helix_nucleation_sites)
    strand_nucleation_sites = find_strand_nucleation_sites(input_sequence)
    strand_regions = extend_strand_regions(input_sequence, strand_nucleation_sites)
    
    helix_positions = [False] * len(input_sequence)
    strand_positions = [False] * len(input_sequence)

    for start, end, _ in helix_regions:
        for i in range(start, end+1):
            helix_positions[i] = True

    for start, end, _ in strand_regions:
        for i in range(start, end+1):
            strand_positions[i] = True
    HELIX=""
    STRAND=""
    print(".....................................................................................")
    print("")
    print("HELIX AND STRAND REGIONS")
    for i in range(0, len(input_sequence), 50):
        seq_line = input_sequence[i:i+50]
        helix_line = ''.join('H' if helix_positions[j] else 'X' for j in range(i, min(i+50, len(input_sequence))))
        strand_line = ''.join('S' if strand_positions[j] else 'X' for j in range(i, min(i+50, len(input_sequence))))
        print(seq_line.ljust(50))
        print(helix_line.ljust(50))
        HELIX += helix_line
        print(strand_line.ljust(50))
        STRAND += strand_line
        print("")
   
    common_regions = ""
    
    min_length = min(len(HELIX), len(STRAND))
    for i in range(min_length):
        if HELIX[i] == 'H' and STRAND[i] == 'S':
            common_regions += "C"
        else:
            if HELIX[i] == 'H':
                common_regions += "H"
            elif STRAND[i] == 'S':
                common_regions += "S"
            else:
                common_regions += "X"
    print("")
    
    start = None
    end = None

# Iterate over the sequence
    for i in range(len(common_regions)):
        if common_regions[i] == 'C':  # If 'C' is found
            if start is None:  # If it's the start of a segment
                start = i
            end = i  # Update the end index as 'C' is encountered
              
            # If it's the last character or the next character is not 'C', print the segment
            if i == len(common_regions) - 1 or common_regions[i+1] != 'C':
                
                segment_sequence = input_sequence[start:end+1]
                alpha_propensity = sum(parameters[residue][0] for residue in segment_sequence) / len(segment_sequence)
                beta_propensity = sum(parameters[residue][1] for residue in segment_sequence) / len(segment_sequence)
                if(alpha_propensity>=beta_propensity):
                    common_regions = common_regions[:start] + common_regions[start:end+1].replace('C', 'H') + common_regions[end+1:]
                elif(alpha_propensity<beta_propensity):
                    common_regions = common_regions[:start] + common_regions[start:end+1].replace('C', 'S') + common_regions[end+1:]
                
                  
                start = None  # Reset start index for next segment
                
    print(".....................................................................................")
    print("Seqeunce After resolvibg conflict")
    print("")
   
    for i in range(0, len(input_sequence), 50):
        seq_segment = input_sequence[i:i+50]
        common_segment = common_regions[i:i+50]
        print( seq_segment.ljust(50))
        print( common_segment.ljust(50))
        print()
          

# Provided input sequence

print_sequence_with_regions(input_sequence)




#Output format (PART A AND B)
# First Line represnt the Amino Acid seqeunce and the second line represet the Classification,H represent Helix and S represent Strand and X reprenst nothing

#OUTPUT FORMAT(PART C)
# First line represnt the amino acid seq,second line represent helical region and third line strand region
